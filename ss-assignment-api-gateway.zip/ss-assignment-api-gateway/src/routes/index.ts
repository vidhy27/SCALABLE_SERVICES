import { Router } from "express";
import { createProxyMiddleware } from "http-proxy-middleware";
import dotenv from "dotenv";
import auth from "../middleware/auth";

dotenv.config();

const router = Router();
router.use(auth);

const USER_SERVICE_URL =
  process.env.USER_SERVICE_URL || "http://localhost:3000";
const POST_SERVICE_URL =
  process.env.POST_SERVICE_URL || "http://localhost:4000";
const COMMENT_SERVICE_URL =
  process.env.COMMENT_SERVICE_URL || "http://localhost:5000";
const LIKE_SERVICE_URL =
  process.env.LIKE_SERVICE_URL || "http://localhost:6000";

console.log("User URL:", USER_SERVICE_URL);
console.log("Post URL:", POST_SERVICE_URL);
console.log("Comment URL:", COMMENT_SERVICE_URL);
console.log("Like URL:", LIKE_SERVICE_URL);

// User Service routes
router.use(
  "/api/v1/users",
  createProxyMiddleware({
    target: USER_SERVICE_URL,
    changeOrigin: true,
    pathRewrite: { "^/api/v1/users": "" },
  }),
);

// Post Service routes
router.use(
  "/api/v1/posts",
  createProxyMiddleware({
    target: POST_SERVICE_URL,
    changeOrigin: true,
    pathRewrite: { "^/api/v1/posts": "" },
  }),
);

// Comment Service routes
router.use(
  "/api/v1/comments",
  createProxyMiddleware({
    target: COMMENT_SERVICE_URL,
    changeOrigin: true,
    pathRewrite: { "^/api/v1/comments": "" },
  }),
);

// Like Service routes
router.use(
  "/api/v1/likes",
  createProxyMiddleware({
    target: LIKE_SERVICE_URL,
    changeOrigin: true,
    pathRewrite: { "^/api/v1/likes": "" },
  }),
);

export default router;
